import './App.css';
import './Search.js';
import Search from './Search.js';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Search />
      </header>
    </div>
  );
}

export default App;